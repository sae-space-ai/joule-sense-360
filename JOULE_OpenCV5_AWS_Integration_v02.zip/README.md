# JOULE SENSE 360° — OpenCV 5 + AWS integration pack

This is a **drop-in repository update**, not a GitHub commit. The image analysis actually uses OpenCV ORB, RANSAC homography and image differencing. Its policy emits actions dependent on the visual result. A meaningful AWS deployment is **prepared but not performed**.

## Quickstart
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
python -m pip install -e '.[dev]'
python -m pytest -q
uvicorn joule.api:app --host 127.0.0.1 --port 8080
curl http://127.0.0.1:8080/health
```
Interactive docs at http://127.0.0.1:8080/docs.
Supply two synthetic/authorized images to POST `/analyze` using multipart form fields `reference` and `current`.

## Safety
Research-only; not a certified disability-assistance mobility device. No public API without authentication and privacy safeguards. Never assert an unobstructed route or fabricate meters. Deploy AWS only after consent, budget and permission approval.

## Integration into existing GitHub repo
The current repository screenshot shows 19 files FLATTENED to root. Repair the structure first (src/joule/, tests/, docs/, .github/workflows/). Then apply this pack, preserving original legal/technical documents and QWEN.md. Do NOT delete docs.
